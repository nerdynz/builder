import moment from 'moment'

export const state = () => ({
  suppliers: null,
  suppliersLastUpdated: null,
  customers: null,
  customersLastUpdated: null,
  people: null,
  peopleLastUpdated: null
})

export const mutations = {
  UPDATE_SUPPLIERS (state, sups) {
    state.suppliers = sups
  },
  UPDATE_SUPPLIERS_LAST_UPDATED (state, d) {
    state.suppliersLastUpdated = d
  },
  UPDATE_CUSTOMERS (state, custs) {
    state.customers = custs
  },
  UPDATE_CUSTOMERS_LAST_UPDATED (state, d) {
    state.customersLastUpdated = d
  },
  UPDATE_PEOPLE (state, custs) {
    state.people = custs
  },
  UPDATE_PEOPLE_LAST_UPDATED (state, d) {
    state.peopleLastUpdated = d
  }
}

export const actions = {
  checkSuppliersLastUpdated ({state, commit}) {
    if (!state.suppliersLastUpdated || moment(state.suppliersLastUpdated).add(45, 'seconds').isBefore(moment())) { // local caching
      this.app.$axios.get('/api/v1/supplier/retrieve').then((resp) => {
        commit('UPDATE_SUPPLIERS', resp.data)
        commit('UPDATE_SUPPLIERS_LAST_UPDATED', new Date())
      })
    }
  },
  checkCustomersLastUpdated ({state, commit}, force) {
    if (force || (!state.customersLastUpdated || moment(state.customersLastUpdated).add(45, 'seconds').isBefore(moment()))) { // local caching
      this.app.$axios.get('/api/v1/customer/retrieve').then((resp) => {
        commit('UPDATE_CUSTOMERS', resp.data)
        commit('UPDATE_CUSTOMERS_LAST_UPDATED', new Date())
      })
    }
  },
  checkPeopleLastUpdated ({state, commit}) {
    if (!state.peopleLastUpdated || moment(state.peopleLastUpdated).add(45, 'seconds').isBefore(moment())) { // local caching
      this.app.$axios.get('/api/v1/person/retrieve').then((resp) => {
        commit('UPDATE_PEOPLE', resp.data)
        commit('UPDATE_PEOPLE_LAST_UPDATED', new Date())
      })
    }
  },

  logout ({commit}, details) {
    commit('LOGOUT')
  }
}

export const getters = {
  suppliers: (state) => {
    return state.suppliers
  },
  customers: (state) => {
    return state.customers
  },
  people: (state) => {
    return state.people
  }
}
