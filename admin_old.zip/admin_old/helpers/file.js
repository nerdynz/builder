function getBase64 (file) {
  var promise = new Promise((resolve, reject) => {
    var reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = function () {
      resolve(reader.result)
    }
    reader.onerror = function (error) {
      resolve(error)
    }
  })
  return promise
}

function getFileFromEvent (ev) {
  var file
  var files
  if (ev && ev.target && ev.target.files) {
    files = ev.target.files
  } else if (ev.dataTransfer.items) {
    files = ev.dataTransfer.items
  } else {
    files = ev.dataTransfer.files
    // Use DataTransfer interface to access the file(s)
  }
  for (let i = 0; i < files.length; i++) {
    if (files[i].kind === 'file') {
      file = files[i].getAsFile()
    } else {
      file = files[i]
    }
  }
  return file
}

export { getBase64, getFileFromEvent }
