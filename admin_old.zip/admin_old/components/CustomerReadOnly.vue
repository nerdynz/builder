<template>
  <span>
    {{customerName}}
  </span>
</template>

<script>
// ... imports
import { byField } from '~/helpers/filters'
import { mapActions, mapGetters } from 'vuex'

export default {
  // COMPONENT
  // ______________________________________
  components: {},
  props: {
    value: Number
  },
  computed: {
    ...mapGetters({
      customers: 'lookups/customers'
    }),
    customerName () {
      if (this.customers && this.customers.length > 0) {
        let cust = byField(this.customers, 'CustomerID', this.value)
        if (cust) {
          return cust.CompanyName
        }
      }
      return 'Not Set'
    }
  },
  methods: {
    ...mapActions({
      checkCustomers: 'lookups/checkCustomersLastUpdated'
    })
  },
  watch: {},
  data () {
    return {
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
    this.checkCustomers()
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
