<template>
  <field name="Contact" label="Contact" for="ContactID">
    <multiselect v-if="contacts && contacts.length > 0" id="ContactID" :options="contacts" track-by="ContactID" label="Name" :value="cVal" @input="emitVal" :disabled="disabled">
        <template slot="singleLabel" slot-scope="{ option }">
        {{ option.Name }} <{{option.Email}}>
      </template>
      <template slot="option" slot-scope="{ option }">
        {{ option.Name }} <{{option.Email}}>
      </template>
    </multiselect>
  </field>
</template>

<script>
// ... imports
import { byField } from '~/helpers/filters'

export default {
  // COMPONENT
  // ______________________________________
  components: {},
  props: {
    customerId: Number,
    value: Number,
    disabled: Boolean
  },
  computed: {
    cVal () {
      return byField(this.contacts, 'ContactID', this.value)
    }
  },
  methods: {
    loadContacts () {
      if (this.customerId > 0) {
        this.$service.retrieve('contact', null, 'customerID', this.customerId).then((contacts) => {
          this.contacts = contacts
          if (!this.value) {
            this.contacts.forEach((c) => {
              if (c.IsPrimary) {
                this.$emit('input', c.ContactID)
              }
            })
          }
        })
      }
    },
    emitVal (val) {
      if (val) {
        this.$emit('input', val.ContactID)
      } else {
        this.$emit('input', 0)
      }
    }
  },
  watch: {
    'customerId' () {
      this.loadContacts()
    }
  },
  data () {
    return {
      contacts: []
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
    this.loadContacts()
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
