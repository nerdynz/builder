<template>
  <field :label="label">
      <b-autocomplete
          :value="name"
          placeholder="e.g. Anne"
          :keep-first="keepFirst"
          :open-on-focus="openOnFocus"
          :data="filteredDataObj"
          field="user.first_name"
          @select="selectOption">
      </b-autocomplete>
  </field>
</template>

<script>
// ... imports

export default {
  // COMPONENT
  // ______________________________________
  name: 'address-lookup',
  components: {
  },
  props: {
    label: String
  },
  computed: {},
  methods: {
    selectOption(opt) {
      
    }
  },
  watch: {},
  data () {
    return {
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
