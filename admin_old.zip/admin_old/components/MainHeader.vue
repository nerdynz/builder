<template>
  <header>

  </header>
</template>

<script>
// ... imports

export default {
  // COMPONENT
  // ______________________________________
  name: 'MainHeader',
  components: {},
  props: {},
  computed: {},
  methods: {},
  watch: {},
  data () {
    return {
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
