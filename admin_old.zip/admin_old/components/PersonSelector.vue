<template>
  <field name="Person" :label="label" for="PersonID">
    <b-select :disabled="disabled" :value="cVal" @input="emitVal">
        <option value="" >Select a manager</option>
        <option
          v-for="person in people"
          :value="person.PersonID"
          :key="person.PersonID">
          {{ person.Name }}
        </option>
    </b-select>
  </field>
</template>

<script>
// ... imports
// import { byField } from '~/helpers/filters'
import { mapActions, mapGetters } from 'vuex'

export default {
  // COMPONENT
  // ______________________________________
  components: {},
  props: {
    label: String,
    value: Number,
    disabled: Boolean
  },
  computed: {
    ...mapGetters({
      people: 'lookups/people'
    }),
    cVal () {
      // return byField(this.people, 'PersonID', this.value)
      return this.value ? this.value : ''
    }
  },
  methods: {
    ...mapActions({
      checkPeople: 'lookups/checkPeopleLastUpdated'
    }),
    emitVal (val) {
      if (val) {
        this.$emit('input', val)
      } else {
        this.$emit('input', 0)
      }
    }
  },
  watch: {},
  data () {
    return {
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
    this.checkPeople()
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
