<template>
  <div class="user-login">
    <div class="media" @click='selectPerson'>
      <picture-avatar :user="person" fullname></picture-avatar>
      <div class="media-right push-down">
        <span class="icon"><i class="far fa-chevron-right"></i></span>
      </div>
    </div>
      <form v-if="isSelected" @submit.prevent="login" class="selected-overlay is-overlay">
        <picture-avatar :user="person" fullname></picture-avatar>
        <div class="u-s-mb">
          <input ref="pass" class="input has-text-centered" type="password" v-model="password" placeholder="password">
        </div>
        
        <input type="submit" class=" login button is-primary" @click="login" value="Login" />
        <a class="back" @click="deselectPerson()">
          <span class="icon">
            <i class="far fa-chevron-left"></i>
          </span>
          back
        </a>
      </form>
  </div>
</template>

<script>
import PictureAvatar from './PictureAvatar'

export default {
  components: {
    PictureAvatar
  },
  props: {
    person: Object,
    index: Number
  },
  computed: {

  },
  methods: {
    login () {
      this.$emit('login-clicked', {
        PersonID: this.person.PersonID,
        Email: this.person.Email,
        Password: this.password
      })
    },
    selectPerson () {
      this.isSelected = true
      this.$emit('user-selected', this.isSelected)
      this.$nextTick(() => {
        this.$refs.pass.focus()
      })
    },
    deselectPerson () {
      this.isSelected = false
      this.$emit('user-selected', this.isSelected)
    }
  },
  data () {
    return {
      isSelected: false,
      password: ''
    }
  }
}
</script>

<style lang="scss">
  @import "~public/scss/variables";

  .user-login {
    min-height: 60px;
    .media {
      cursor: pointer;
      align-items: center;

      &:hover {
        color: $primary;
        strong {
          color: $primary;
        }
      }
    }

    .main-image {
      width:80px;
    }

    .main-image, .list-image {
      border-radius: 50%;
    }

    .selected-overlay {
      background-color: white;
      z-index: 500;
      padding: 1rem;
    }

    .login.button {
      position: absolute;
      right: 1rem;
      bottom: 1rem;
    }

    .back {
      position: absolute;
      bottom: 1rem;
      left: 1rem;
    }

    .picture-avatar {
      width: 100%;
      justify-content: flex-start;
      .name {
        color: $black;
        text-align: center;
        padding-left: 1rem;
      }
    }

    .selected-overlay {
      .picture-avatar {
        flex-direction: column;
        .avatar-img {
          img {
            width: 100px;
            height: 100px;
            max-height: 100px;
            border-radius: 100px;
          }
        }
        .name {
          font-size: 24px;
        }
      }
    }
  }
</style>
