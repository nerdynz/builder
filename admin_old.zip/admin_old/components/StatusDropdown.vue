<template>
  <field :label="label" for="Statuses" :class="cssClass">
    <b-select :disabled="disabled" :value="value" @input="emitVal">
      <option value="">All</option>
      <option value="Active">Active</option>
      <option
        v-for="status in statuses"
        :value="status"
        :key="status">
        {{ status }}
      </option>
    </b-select>
  </field>
</template>

<script>
export default {
  // COMPONENT
  // ______________________________________
  components: {},
  props: {
    label: String,
    value: String,
    disabled: Boolean,
    showAll: Boolean,
    showActive: Boolean
  },
  computed: {
    cssClass () {
      let base = 'select-parent '
      if (this.value === 'Quoting') return base + 'is-info'
      return ''
    }
  },
  methods: {
    emitVal (val) {
      this.$emit('input', val)
    }
  },
  watch: {},
  data () {
    return {
      statuses: ['Quoting', 'In progress', 'Completed', 'Invoicing', 'Archived']
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
