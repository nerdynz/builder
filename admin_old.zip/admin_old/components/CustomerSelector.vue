<template>
  <field name="Customer" label="Customer" for="CustomerID">
    <multiselect v-if="customers && customers.length > 0" id="CustomerID" :options="customers" track-by="CustomerID" label="CompanyName" :value="cVal" @input="emitVal" :disabled="disabled" />
  </field>
</template>

<script>
// ... imports
import { byField } from '~/helpers/filters'
import { mapActions, mapGetters } from 'vuex'

export default {
  // COMPONENT
  // ______________________________________
  components: {},
  props: {
    value: Number,
    disabled: Boolean
  },
  computed: {
    ...mapGetters({
      customers: 'lookups/customers'
    }),
    cVal () {
      return byField(this.customers, 'CustomerID', this.value)
    }
  },
  methods: {
    ...mapActions({
      checkCustomers: 'lookups/checkCustomersLastUpdated'
    }),
    emitVal (val) {
      if (val) {
        this.$emit('input', val.CustomerID)
      } else {
        this.$emit('input', 0)
      }
    }
  },
  watch: {},
  data () {
    return {
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
    this.checkCustomers()
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">

</style>
