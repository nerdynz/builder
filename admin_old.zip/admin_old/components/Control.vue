<template>
  <field :label="label" :for="name">
    <div v-if="type === 'date'" class="field has-addons">
      <p class="control" v-if="showPrevNext"><button class="button" @click="lessOneDay"><b-icon icon="angle-left"></b-icon></button></p>
      <p class="control u-fw">
        <b-datepicker ref="field" :value="dateVal" @input="dateChanged"
          :label="label"
          :disabled="disabled"
          placeholder="" class="title-input-child" 
          :date-formatter="dateFormatter"
          icon="calendar"
          @focus="focus"
          @blur="blur"
        >
        </b-datepicker>
      </p>
      <p class="control" v-if="showPrevNext" ><button class="button" @click="moreOneDay"><b-icon icon="angle-right"></b-icon></button></p>
    </div>
    <div v-else-if="type === 'datetime'" class="field has-addons">
      <p class="control u-fw" >
        <b-datepicker ref="field" :value="dateVal" @input="dateChanged"
          :label="label"
          :disabled="disabled"
          placeholder="" class="title-input-child" 
        >
        </b-datepicker>
      </p>
    </div>
    <div v-else-if="type === 'select'" class="field has-addons"> 
      <div class="control">
        <p class="select">
          <select  
          :disabled="disabled"
          :value="value === 0 ? '' : value"
          @focus="focus"
          @blur="blur"
          @input="input">
            <option value="">{{placeholder ? placeholder : '- not specified -'}}</option>
            <option 
              v-for="(option, index) in options" 
              :key="index"
              :value="optionType === 'number' ? Number(option[optionValue]) : option[optionValue]">
                {{option[optionLabel]}}
            </option>
          </select>
        </p>
      </div>
    </div>
    <div v-else-if="type === 'number'" class="field  numeric" :class="{'is-readonly': readonly, 'has-addons': showButtons}"> 
      <p class="control">
        <input
          ref="field"
          :id="name" 
          :name="name"
          type="number"
          :placeholder="placeholder"
          :disabled="disabled"
          :value="value"
          :class="klass"
          class="numeric-input"
          autocomplete="off"
          :readonly="readonly"
          :maxlength="maxlength"
          @input="input"
          @change="change"
          @focus="focus"
          @blur="blur" 
        />
      </p>
      <p v-if="showButtons" class="control">
        <button class="button" :class="klass" @click="decrement">
          <i class="fa fa-minus"></i>
        </button>
      </p>
      <p v-if="showButtons" class="control">
        <button class="button" :class="klass" @click="increment">
          <i class="fa fa-plus"></i>
        </button>
      </p>
    </div>
    <p v-else-if="type === 'textarea'" class="control">
      <textarea 
        ref="field" 
        :id="name" 
        :name="name"
        :placeholder="placeholder"
        :disabled="disabled"
        :value="value"
        :class="klass"
        autocomplete="off"
        :maxlength="maxlength"
        @input="input"
        @change="change"
        @focus="focus"
        @blur="blur"
      >
      </textarea>
    </p>
    <p v-else class="control">
      <input 
        ref="field" 
        :id="name" 
        :name="name"
        :type="type"
        :placeholder="placeholder"
        :disabled="disabled"
        :value="value"
        :class="klass"
        autocomplete="off"
        :readonly="readonly"
        :maxlength="maxlength"
        @input="input"
        @change="change"
        @focus="focus"
        @blur="blur" 
        @keydown="keydown"
      />
    </p>
  </field>
</template>

<script>
import {fmtDateTime} from '~/helpers/format'

export default {
  // COMPONENT
  // ______________________________________
  name: 'Control',
  inject: {
    $validator: '$validator'
  },
  components: {
  },
  props: {
    hint: {
      Type: null
    },
    name: {
      type: String,
      required: true
    },
    maxlength: String,
    showButtons: {
      type: Boolean,
      default: false
    },
    className: {
      type: String,
      default: ''
    },
    size: String,
    value: {
      required: true
    },
    label: String,
    placeholder: {
      type: String
    },
    type: {
      type: String,
      default: 'text'
    },
    readonly: Boolean,
    disabled: Boolean,
    prefix: String,
    step: {
      type: Number,
      default: 1
    },
    options: Array,
    optionLabel: {
      type: String,
      default: 'label'
    },
    optionValue: {
      type: String,
      default: 'value'
    },
    optionType: {
      type: String,
      default: 'string'
    },
    tooltip: {
      type: Object
    },
    showPrevNext: {
      type: Boolean
    }
    // errors: Array,
    // validation: {
    //   type: Object,
    //   default () {
    //     return {
    //       rules: {
    //       },
    //       errors: {
    //       }
    //     }
    //   }
    // }
  },
  computed: {
    hasValue () {
      return !!this.value
    },
    klass () {
      let className = this.className + ''

      if (this.type === 'textarea') {
        className += ' textarea '
      } else {
        className += ' input '
      }
      if (this.size) {
        className += ` is-${this.size.toLowerCase()}`
      }
      // if (this.readonly) {
      //   className += ' is-readonyl '
      // }
      return className
    },
    dateVal () {
      let value = this.value
      if (this.type.indexOf('date') === 0) {
        if (value) {
          value = new Date(value) // str to date
        } else {
          value = new Date()
        }
        return value
      }
      return this.value
    }
  },
  methods: {
    lessOneDay () {
      var date = this.dateVal
      date.setDate(date.getDate() - 1)
      this.dateChanged(date)
    },
    moreOneDay () {
      var date = this.dateVal
      date.setDate(date.getDate() + 1)
      this.dateChanged(date)
    },
    dateFormatter (date) {
      return fmtDateTime(date, 'dddd, mmmm dS, yyyy')
    },
    placeChanged (a, b, c) {
      this.$emit('placechanged', a, b, c)
    },
    decrement () {
      var newVal = this.value - this.step
      this.$emit('input', Number(newVal))
    },
    increment () {
      var newVal = this.value + this.step
      this.$emit('input', Number(newVal))
    },
    openDatePicker () {
      this.$refs['field'].open()
    },
    clearDatePicker () {
      this.$emit('input', '')
    },
    dateChanged (val) {
      let origDate = fmtDateTime(this.value, 'isoUtcDateTime')
      let newDate = fmtDateTime(val, 'isoUtcDateTime')
      if (newDate === origDate) {
        return // false positive, its just formatting
      }
      this.$emit('input', newDate)
    },
    labelClicked (ev) {
      this.$refs['field'].focus()
    },
    focus (ev) {
      this.isSelected = true
      this.$emit('focus', ev, ev.target.value)
    },
    blur (ev) {
      this.isSelected = false
      this.$emit('blur', ev, ev.target.value)
    },
    keydown (ev) {
      this.$emit('keydown', ev, ev.target.value)
    },
    change (valueOrEvent) {
      let value = valueOrEvent
      if (valueOrEvent && valueOrEvent.target) {
        value = valueOrEvent.target.value
      }

      if (this.type === 'number') {
        this.$emit('change', Number(value))
      } else {
        this.$emit('change', value)
      }
    },
    input (valueOrEvent) {
      let value = valueOrEvent
      if (valueOrEvent && valueOrEvent.target) {
        value = valueOrEvent.target.value
      }

      if (this.type === 'number' || (this.type === 'select' && this.optionType === 'number')) {
        this.$emit('input', Number(value))
      } else {
        this.$emit('input', value)
      }
    }
  },
  data () {
    return {
      isSelected: false
    }
  },

  // LIFECYCLE METHODS
  // ______________________________________
  beforeCreate () {
  },
  created () {
  },
  beforeMount () {
  },
  mounted () {
  },
  beforeUpdate () {
  },
  updated () {
  },
  beforeDestroy () {
  },
  destroyed () {
  }
}
</script>

<style lang="scss">
  .field {
    .numeric-input {
      width: 80px;
    }
  }
</style>
