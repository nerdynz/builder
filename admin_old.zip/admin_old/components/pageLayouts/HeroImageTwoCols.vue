<template>
  <div class="layout-example is-clearfix" @click="layoutClicked" :class="{'is-selected': value === selectVal }">
    <div class="layout-image">
      <svg viewBox="0 0 640 750"
           version="1.1"
           xmlns="http://www.w3.org/2000/svg"
           xmlns:xlink="http://www.w3.org/1999/xlink"
           style="background: #FFFFFF;">
        <defs>
          <rect id="path-1"
                x="0"
                y="0"
                width="640"
                height="750"></rect>
          <mask id="mask-2"
                maskContentUnits="userSpaceOnUse"
                maskUnits="objectBoundingBox"
                x="0"
                y="0"
                width="640"
                height="750"
                fill="white">
            <use xlink:href="#path-1"></use>
          </mask>
        </defs>
        <g id="Page-1"
           stroke="none"
           stroke-width="1"
           fill="none"
           fill-rule="evenodd">
          <use id="Rectangle"
               stroke="#E4E4E4"
               mask="url(#mask-2)"
               stroke-width="8"
               xlink:href="#path-1"></use>
          <text id="Lorem-Ipsum"
                font-family="Helvetica"
                font-size="24"
                font-weight="normal"
                fill="#B6B6B6">
            <tspan x="25"
                   y="419">Lorem Ipsum</tspan>
          </text>
          <text id="Lorem-ipsum-dolor-si"
                font-family="Helvetica"
                font-size="14"
                font-weight="normal"
                fill="#B6B6B6">
            <tspan x="24"
                   y="448">Lorem ipsum dolor sit amet, consectetur </tspan>
            <tspan x="24"
                   y="465">adipiscing elit. Duis malesuada bibendum </tspan>
            <tspan x="24"
                   y="482">leo. In venenatis ligula et leo interdum, id </tspan>
            <tspan x="24"
                   y="499">laoreet sapien luctus. Sed non massa lectus. </tspan>
            <tspan x="24"
                   y="516">In sed aliquet velit. Aliquam erat volutpat. </tspan>
            <tspan x="24"
                   y="533">Nunc elementum justo id lorem ultrices, a </tspan>
            <tspan x="24"
                   y="550">viverra tellus mattis. Cras faucibus interdum </tspan>
            <tspan x="24"
                   y="567">iaculis. Praesent eu velit id orci rutrum </tspan>
            <tspan x="24"
                   y="584">commodo. Nullam hendrerit diam in dolor </tspan>
            <tspan x="24"
                   y="601">pulvinar malesuada. Maecenas vel nulla non </tspan>
            <tspan x="24"
                   y="618">ipsum finibus sagittis. Sed ac orci nibh. </tspan>
            <tspan x="24"
                   y="635">Vestibulum congue a lectus vel congue. </tspan>
            <tspan x="24"
                   y="652">Curabitur vehicula lorem et turpis imperdiet, </tspan>
            <tspan x="24"
                   y="669">sed varius mi scelerisque. Fusce varius nibh </tspan>
            <tspan x="24"
                   y="686">efficitur, tristique nunc ut, euismod quam. </tspan>
            <tspan x="24"
                   y="703">Curabitur luctus porttitor eros vel semper.</tspan>
          </text>
          <text id="Lorem-Ipsum"
                font-family="Helvetica"
                font-size="24"
                font-weight="normal"
                fill="#B6B6B6">
            <tspan x="336"
                   y="419">Lorem Ipsum</tspan>
          </text>
          <text id="Lorem-ipsum-dolor-si"
                font-family="Helvetica"
                font-size="14"
                font-weight="normal"
                fill="#B6B6B6">
            <tspan x="335"
                   y="448">Lorem ipsum dolor sit amet, consectetur </tspan>
            <tspan x="335"
                   y="465">adipiscing elit. Duis malesuada bibendum </tspan>
            <tspan x="335"
                   y="482">leo. In venenatis ligula et leo interdum, id </tspan>
            <tspan x="335"
                   y="499">laoreet sapien luctus. Sed non massa lectus. </tspan>
            <tspan x="335"
                   y="516">In sed aliquet velit. Aliquam erat volutpat. </tspan>
            <tspan x="335"
                   y="533">Nunc elementum justo id lorem ultrices, a </tspan>
            <tspan x="335"
                   y="550">viverra tellus mattis. Cras faucibus interdum </tspan>
            <tspan x="335"
                   y="567">iaculis. Praesent eu velit id orci rutrum </tspan>
            <tspan x="335"
                   y="584">commodo. Nullam hendrerit diam in dolor </tspan>
            <tspan x="335"
                   y="601">pulvinar malesuada. Maecenas vel nulla non </tspan>
            <tspan x="335"
                   y="618">ipsum finibus sagittis. Sed ac orci nibh. </tspan>
            <tspan x="335"
                   y="635">Vestibulum congue a lectus vel congue. </tspan>
            <tspan x="335"
                   y="652">Curabitur vehicula lorem et turpis imperdiet, </tspan>
            <tspan x="335"
                   y="669">sed varius mi scelerisque. Fusce varius nibh </tspan>
            <tspan x="335"
                   y="686">efficitur, tristique nunc ut, euismod quam. </tspan>
            <tspan x="335"
                   y="703">Curabitur luctus porttitor eros vel semper.</tspan>
          </text>
          <g id="image-placeholder_3x2"
             transform="translate(24.000000, 32.000000)">
            <g id="placeholder">
              <rect id="Rectangle-path"
                    fill="#E4E4E4"
                    x="0"
                    y="0"
                    width="591"
                    height="333"></rect>
              <g id="Group"
                 transform="translate(210.000000, 102.000000)"
                 fill="#FFFFFF">
                <path d="M0.0278866667,0.516666667 L0.0278866667,127.55 L171.972113,127.55 L171.972113,0.516666667 L0.0278866667,0.516666667 Z M158.112507,113.773667 L14.6951933,113.773667 L14.6951933,14.2917667 L158.112507,14.2917667 L158.112507,113.773667 L158.112507,113.773667 Z"
                      id="Shape"></path>
                <polygon id="Shape"
                         points="22.4084 103.0597 51.9689067 73.8802667 63.0442467 78.3807 97.9907333 43.4465333 111.746587 58.8977333 117.952087 55.3778 151.532707 103.0597"></polygon>
                <ellipse id="Oval"
                         cx="56.5576933"
                         cy="39.5886667"
                         rx="12.9100667"
                         ry="12.1236667"></ellipse>
              </g>
            </g>
          </g>
        </g>
      </svg>
    </div>
    <div class="layout-label">{{selectVal}}</div>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: String,
      required: true
    }
  },
  methods: {
    layoutClicked () {
      this.$emit('input', this.selectVal)
    }
  },
  data () {
    return {
      selectVal: 'Hero Image w\' Two Columns'
    }
  }
}
</script>
