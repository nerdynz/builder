<template>
  <div class="layout-example is-clearfix" @click="layoutClicked" :class="{'is-selected': value === selectVal }">
    <div class="layout-image">
      <svg viewBox="0 0 640 750" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="background: #FFFFFF;">
          <!-- Generator: Sketch 41 (35326) - http://www.bohemiancoding.com/sketch -->
          <title>Wireframes</title>
          <desc>Created with Sketch.</desc>
          <defs>
              <rect id="path-1" x="0" y="0" width="640" height="750"></rect>
              <mask id="mask-2" maskContentUnits="userSpaceOnUse" maskUnits="objectBoundingBox" x="0" y="0" width="640" height="750" fill="white">
                  <use xlink:href="#path-1"></use>
              </mask>
          </defs>
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <use id="Rectangle" stroke="#E4E4E4" mask="url(#mask-2)" stroke-width="8" xlink:href="#path-1"></use>
              <text id="Lorem-Ipsum" font-family="Helvetica" font-size="24" font-weight="normal" fill="#B6B6B6">
                  <tspan x="23" y="40">Lorem ipsum dolor sit amet</tspan>
              </text>
              <text id="Lorem-ipsum-dolor-si" font-family="Helvetica" font-size="14" font-weight="normal" fill="#B6B6B6">
                  <tspan x="24" y="67.5681256">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis malesuada bibendum leo. In </tspan>
                  <tspan x="24" y="84.5681256">venenatis ligula et leo interdum, id laoreet sapien luctus. Sed non massa lectus. In sed aliquet </tspan>
                  <tspan x="24" y="101.568126">velit. Aliquam erat volutpat. Nunc elementum justo id lorem ultrices, a viverra tellus mattis. Cras </tspan>
                  <tspan x="24" y="118.568126">faucibus interdum iaculis. Praesent eu velit id orci rutrum commodo. Nullam hendrerit diam in </tspan>
                  <tspan x="24" y="135.568126">dolor pulvinar malesuada. Maecenas vel nulla non ipsum finibus sagittis. Sed ac orci nibh. </tspan>
                  <tspan x="24" y="152.568126">Vestibulum congue a lectus vel congue. Curabitur vehicula lorem et turpis imperdiet, sed varius </tspan>
                  <tspan x="24" y="169.568126">mi scelerisque. Fusce varius nibh efficitur, tristique nunc ut, euismod quam. Curabitur luctus </tspan>
                  <tspan x="24" y="186.568126">porttitor eros vel semper.</tspan>
                  <tspan x="24" y="203.568126"></tspan>
                  <tspan x="24" y="220.568126">Duis hendrerit sed elit sit amet laoreet. Sed vel neque tristique, scelerisque mi sed, tincidunt </tspan>
                  <tspan x="24" y="237.568126">metus. Phasellus convallis condimentum finibus. Phasellus porta purus ac elementum mollis. </tspan>
                  <tspan x="24" y="254.568126">Nulla nec quam egestas, consectetur diam ut, dictum ligula. Donec mattis ipsum sed lectus </tspan>
                  <tspan x="24" y="271.568126">molestie efficitur eu et massa. Etiam et odio vel neque maximus cursus. Etiam magna sapien, </tspan>
                  <tspan x="24" y="288.568126">congue a hendrerit ut, efficitur at orci.</tspan>
                  <tspan x="24" y="305.568126"></tspan>
                  <tspan x="24" y="322.568126">Fusce cursus mattis nibh et lobortis. Nullam ultricies feugiat enim a accumsan. Pellentesque </tspan>
                  <tspan x="24" y="339.568126">vestibulum in nibh sit amet vulputate. Donec nisi magna, tristique nec hendrerit a, consectetur </tspan>
                  <tspan x="24" y="356.568126">vitae odio. Fusce placerat velit felis, nec mattis urna pharetra in. Sed eu turpis placerat, </tspan>
                  <tspan x="24" y="373.568126">sodales elit a, suscipit justo. Aliquam luctus tincidunt rutrum. Maecenas ut odio non mauris </tspan>
                  <tspan x="24" y="390.568126">placerat lacinia sit amet sed ipsum. Donec et nisl quis turpis semper vulputate. Nullam </tspan>
                  <tspan x="24" y="407.568126">consequat dui in leo posuere, non euismod velit venenatis. Maecenas ultrices mi ut luctus </tspan>
                  <tspan x="24" y="424.568126">laoreet.</tspan>
                  <tspan x="24" y="441.568126"></tspan>
                  <tspan x="24" y="458.568126">Cras imperdiet massa malesuada metus lacinia convallis. Curabitur pharetra urna vitae enim </tspan>
                  <tspan x="24" y="475.568126">gravida lobortis. Duis viverra, eros at mollis vulputate, purus enim euismod ante, et elementum </tspan>
                  <tspan x="24" y="492.568126">nunc nunc eget dui. Sed facilisis rhoncus leo, quis vehicula ante pellentesque sed. Donec </tspan>
                  <tspan x="24" y="509.568126">tempus tortor justo, eget lobortis tortor pellentesque vel. Mauris at purus urna. Duis hendrerit </tspan>
                  <tspan x="24" y="526.568126">mi at ligula mollis, non imperdiet enim consectetur. In semper dignissim magna, ac fringilla </tspan>
                  <tspan x="24" y="543.568126">risus porttitor id. Sed vel bibendum elit. Suspendisse potenti. Nullam varius lectus nisl, vitae </tspan>
                  <tspan x="24" y="560.568126">fermentum enim fringilla ac. Vestibulum dignissim et sapien nec placerat.</tspan>
                  <tspan x="24" y="577.568126"></tspan>
                  <tspan x="24" y="594.568126">Proin gravida, odio quis placerat condimentum, nisi dolor malesuada elit, a suscipit risus nunc </tspan>
                  <tspan x="24" y="611.568126">in odio. Ut id ex turpis. Etiam ut luctus leo. Maecenas facilisis, dui non vestibulum dictum, lacus </tspan>
                  <tspan x="24" y="628.568126">neque maximus risus, vitae efficitur quam sapien ut nulla. In commodo, est ac aliquam pretium, </tspan>
                  <tspan x="24" y="645.568126">massa ipsum tristique velit, a tincidunt enim libero eget libero. Nulla cursus volutpat diam </tspan>
                  <tspan x="24" y="662.568126">elementum laoreet. Fusce ac libero maximus, viverra mauris nec, rutrum erat. Curabitur eget </tspan>
                  <tspan x="24" y="679.568126">ex suscipit, porta urna id, lacinia ex. Nunc pretium vestibulum quam, eu maximus ipsum </tspan>
                  <tspan x="24" y="696.568126">interdum eu. Praesent at interdum neque. Integer et odio quam. Curabitur sit amet turpis enim. </tspan>
                  <tspan x="24" y="713.568126">In bibendum, tortor vitae mollis aliquet, lectus nibh rhoncus nulla, eu tincidunt ante lacus id </tspan>
                  <tspan x="24" y="730.568126">augue. Morbi tempus accumsan nunc, quis volutpat nunc iaculis in.</tspan>
              </text>
          </g>
      </svg>
    </div>
    <div class="layout-label">{{selectVal}}</div>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: String,
      required: true
    }
  },
  methods: {
    layoutClicked () {
      this.$emit('input', this.selectVal)
    }
  },
  data () {
    return {
      selectVal: 'Standard'
    }
  }
}
</script>
