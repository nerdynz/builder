import VueFroala from './vue-froala'

export default VueFroala
