import Vue from 'vue'
import VeeValidate from 'vee-validate'
import PhoneNumber from 'awesome-phonenumber'
import Multiselect from 'vue-multiselect'
import ImageUpload from '~/components/ImageUpload'
import RichText from '~/components/RichText'
import Fab from '~/components/Fab'
import AddressLookup from 'vue-google-autocomplete'
import VueFroala from '~/components/froala-editor'
import Sortable from 'sortablejs'
import {fmtDate, fmtDateTime} from '~/helpers/format'
import {focusElement} from '~/helpers/helpers'
import VueDragDrop from 'vue-drag-drop'
Vue.use(VueDragDrop)

const phoneNumber = {
  getMessage: field => `${field} is not a valid phone number`,
  validate (value) {
    return new Promise(resolve => {
      let phone = new PhoneNumber(value)
      resolve({ valid: phone.isValid() })
    })
  }
}

VeeValidate.Validator.extend('phone', phoneNumber)

Vue.use(VeeValidate, {
  inject: false
})

Vue.mixin({
  methods: {
    fmtDate,
    fmtDateTime,
    focusElement
  }
})

Vue.component('address-lookup', AddressLookup)
Vue.component('fab', Fab)
Vue.component('multiselect', Multiselect)
Vue.component('image-upload', ImageUpload)
Vue.component('rich-text', RichText)
Vue.use(require('vue-prevent-parent-scroll'))
Vue.use(Tooltip)
Vue.use(VueFroala, {
  defaultConfig: {
    key: 'cC7B7A6C4C-11A2B2G2F1C9B3B1C6E2C1woJ-7oidtf1g1B1H-8l=='
  }
})
Vue.directive('sortable', {
  inserted: function (el, binding) {
    new Sortable(el, binding.value || {}) // eslint-disable-line no-new
  }
})
require('~/helpers/imageupload')
